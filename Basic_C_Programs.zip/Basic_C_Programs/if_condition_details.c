#include<stdio.h>
int main(){
int n = -1;
if(n){
  printf("True");
}
else{
  printf("False");
}
return 0;
}