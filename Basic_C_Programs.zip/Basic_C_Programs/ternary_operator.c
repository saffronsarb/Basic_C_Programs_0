#include<stdio.h>
//to demonstrate ternary operator
int main(){
  system("cls");
  int x =9;
  int y = (x>6)?4:6;
  printf("%d",y);

 return 0;
}