 #include<stdio.h>
 int main(){
    system("cls");
    char c;
    printf("Enter a character: ");
    scanf("%c",&c);
    int a=(int)c;
    printf("The ASCII value of %c is %d",c,a);
return 0;
 }