//looping/iterative statements

//entry control 
//while
//for
// do while
//exit control



//WAP to print first 10 numbers

#include<stdio.h>
int main(){
   int i=0;
   while(i<=10){
     printf("i=%d \n", i);
     i++;

  }

return 0;

 }
