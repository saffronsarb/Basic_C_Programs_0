#include<stdio.h>
int main(){  
  int hours=45;
  if(hours>40){
    printf("You will not get overtime pay %d \n",hours-40);
    
  }
  else{
    printf("You will not get overtime pay %d \n",hours);
  }
 
 return 0; 
  }