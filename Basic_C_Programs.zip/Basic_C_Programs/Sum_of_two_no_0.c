#include<stdio.h>
int main(){
    int x=5;
    int y=9,z;
    system("cls");
    z=x+y;
    printf("the sum of two integers is %d",z);
    return 0;    
}