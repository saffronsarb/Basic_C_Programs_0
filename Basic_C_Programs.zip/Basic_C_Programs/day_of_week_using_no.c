#include <stdio.h>
// WAP to print day of week using no
int main(void) {
    system("cls");
    int n;
    printf("Enter day number (1-7): ");
    scanf("%d", &n);

   
    if (n == 1)
        printf("Monday\n");
    else if (n == 2)
        printf("Tuesday\n");
    else if (n == 3)
        printf("Wednesday\n");
    else if (n == 4)
        printf("Thursday\n");
    else if (n == 5)
        printf("Friday\n");
    else if (n == 6)
        printf("Saturday\n");
    else if (n == 7)
        printf("Sunday\n");    
    else
        printf("Invalid day number. Please enter a number between 1 and 7.\n");

    return 0;
}